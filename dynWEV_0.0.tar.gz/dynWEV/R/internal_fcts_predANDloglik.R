### Helper functions for predictratingdist ####

#Actual function for integrating and calculating the probabilities
preddist <- function(row, thetas_lower, thetas_upper, paramDf,V, SV, model,
                     precision=3, c_precision=200,
                     maxrt=15, subdivisions=100L,
                     stop.on.error = FALSE, simult_conf=TRUE,
                     .progress = TRUE, pb=NULL) {
  if (model != "2DSD") {
    vth1 <- ifelse(row$response =="upper", thetas_upper[row$rating], thetas_lower[(row$rating)])
    vth2 <- ifelse(row$response =="upper", thetas_upper[(row$rating+1)], thetas_lower[(row$rating+1)])
  } else {
    vth1 <- ifelse(row$response =="upper", thetas_upper[row$rating], rev(thetas_lower)[(row$rating+1)])
    vth2 <- ifelse(row$response =="upper", thetas_upper[(row$rating+1)], rev(thetas_lower)[(row$rating)])
  }


  integrand <- with(paramDf, switch(which(model== c("WEVmu", "2DSD")),
                                    function(t) return(dWEVmu(t, vth1,vth2,
                                                                  response=as.character(row$response), tau=tau, a=a,
                                                                  v = (-1)^(row$stimulus=="lower")*V[row$condition],
                                                                  t0 = t0, z = z, sz = sz, st0=st0,
                                                                  sv = SV[row$condition], w=w, sig=sig, sigmu=sigmu,
                                                                  z_absolute = FALSE,  simult_conf=simult_conf, precision = precision)),
                                    function(t) return(d2DSD(t, vth1,vth2,
                                                             response=as.character(row$response), tau=tau, a=a,
                                                             v = (-1)^(row$stimulus=="lower")*V[row$condition],
                                                             t0 = t0, z = z, sz = sz, st0=st0,
                                                             sv = SV[row$condition],
                                                             z_absolute = FALSE,  simult_conf=simult_conf, precision = precision))))


  p <- integrate(integrand, lower=paramDf$t0, upper=maxrt, subdivisions = subdivisions,
                 stop.on.error = stop.on.error)
  if (.progress) pb$tick()
  return(data.frame(p = p$value, info = p$message, err = p$abs.error))
}

