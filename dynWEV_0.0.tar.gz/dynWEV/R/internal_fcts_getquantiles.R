get_quantiles_subgroup <- function(cdf, rt, probs) {
  q <- rep(0, length(probs))
  for (i in 1:length(probs)) {
    loc <- min(which(cdf>= probs[i]))
    q[i] <- rt[loc]
  }
  return(data.frame(p = probs, q = q))
}
