### Helper functions for the fitting routine ####


create_grid_RM_dec <- function(init_grid=NULL, nConds, mint0=0,
                               optim_method="bobyqa") {
  ## Function that returns the intial grid for the grid search before the optimisation.
  ## Input: model (in "IRM", "PCRM")
  ## Output: a data.frame with rows equal to the initial parameters
  if (is.null(init_grid)) {

    init_grid <- expand.grid(vmin = seq(0.01, 0.4, length.out = 4), ### vmin = drift rate in first condition \in (0,\infty)]
                             vmax = seq(2, 5, length.out = 4),     ### vmax = mean drift rate in last condition \in (\vmin,\infty)]
                             a = seq(2,6, length.out = 5),           ### a = boundary separation for first accumulator \in (0,\infty)]
                             b = seq(2,6, length.out = 5),         ### b = boundary separation for second accumulator \in (0,\infty)]
                             t0 = seq(max(0, mint0-0.2),max(0, mint0-0.1),by=0.1), ### t0 = minimal motor time \in (0,\infty)]
                             st0 = seq(0, 0.2, length.out=4))         #### st0 = range of uniform distributed motor time \in (0,\infty)]
  }

  if (optim_method=="Nelder-Mead") {
    ## change parametrisation (should be on the whole real line) and
    #  span V-parameters between vmin and vmax equidistantly for all conditions
    inits <- data.frame(matrix(data=NA, nrow= nrow(init_grid),
                               ncol = 3+nConds))
    for (i in 0:(nConds-1)){
      if (nConds == 1) {
        inits[,1] <- log((init_grid$vmin+init_grid$vmax)/2)
      } else {
        inits[,i+1] <- log(init_grid$vmin+(i/(nConds-1))^2*(init_grid$vmax-init_grid$vmin)) ###  We assume a different V (mean drift rate) for the different conditions --> nConds parameters
      }
    }
    inits[,nConds+1] <- log(init_grid$a)
    inits[,nConds+2] <- log(init_grid$b)
    inits[,nConds+3] <- log(init_grid$t0)
    inits[,nConds+4] <- log(init_grid$st0)


    ##replace all +-Inf with big/tiny numbers
    inits[inits==Inf]<- 1e6
    inits[inits==-Inf]<- -1e6
    return(inits)
  } else {
    if (nConds==1) {
      init_grid$v1 <- (init_grid$vmin+init_grid$vmax)/2
    } else {
      for (i in 0:(nConds-1)){
        init_grid[paste("v", i+1, sep="")] <- init_grid$vmin+(i/(nConds-1))^2*(init_grid$vmax-init_grid$vmin)
      }
    }
    return(init_grid[c('a', 'b', 't0', 'st0',
                       paste("v", 1:nConds, sep=""))])
  }
}


neglikelihood_free_RM_dec<-   function(p, data, model, nConds)
{
  # get parameter vector back from real transformations
  p <- c(t(p))

  paramDf <-  data.frame(matrix(nrow=1, ncol=0))
  paramDf[,paste("v",1:(nConds), sep="")] <- exp(p[1:(nConds)])
  paramDf$a <- exp(p[(1+nConds)])
  paramDf$b <- exp(p[2+nConds])
  paramDf$t0 <- exp(p[3+nConds])
  paramDf$st0 <- exp(p[4+nConds])




  if (any(is.infinite(t(paramDf))) || any(is.na(t(paramDf)))) {
    return(1e12)
  }
  negloglik <- -LogLikRMdec(data, paramDf, model)

  return(negloglik)
}




neglikelihood_bounded_RM_dec <-   function(p, data, model, nConds)
{
  # get parameter vector back from real transformations
  paramDf <- data.frame(matrix(NA, nrow=1, ncol=5+nConds))
  paramDf[1,] <- p
  names(paramDf) <- c("a", "b", 't0', 'st0', paste("v", 1:nConds, sep=""))
  negloglik <- -LogLikRMdec(data, paramDf, model)
  return(negloglik)
}

