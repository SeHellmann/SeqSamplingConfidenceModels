### Helper functions for the fitting routine ####

create_grid <- function(init_grid=NULL, model="WEVmu",  restr_tau, nConds, nRatings, sym_thetas, mint0=0.2,
                        optim_method="bobyqa", simult_conf) {
  ## Function that returns the intial grid for the grid search before the optimisation.
  ## Input: model (in "2DSD", "WEVd", "WEVmu", "WEVabsmu")
  ## Output: a data.frame with rows equal to the initial parameters
  if ( nRatings < 2) {
    stop("There has to be at least two rating levels")
  }
  if (is.null(init_grid)) {
    if (mint0 < 0.2) {mint0 <- 0.2}
    if (restr_tau==Inf) {
      tau = seq(0.3, 1, length.out = 3)
    } else {
      if (!(is.numeric(restr_tau) && restr_tau >0)) {stop(paste("restr_tau must be numeric and positive. But restr_tau=", restr_tau, sep=""))}
      tau = seq(0.3*restr_tau,0.9*restr_tau, length.out = 4)
    }
    init_grid <- switch(which(model==c( "WEVmu","2DSD")),
                        expand.grid(a = c(1.3,1.7, 2.5),                         ### a = distance btw. upper and lower bound \in (0,\infty)]
                                    vmin = c(0.01, 0.1),                    ### vmin = mean drift rate in first condition \in (0,\infty)]
                                    vmax = c(1.4, 2.5, 3.7, 5),                     ### vmax = mean drift rate in last condition \in (\vmin,\infty)]
                                    sv = c(0.01, 0.8, 1.5),                      ### sv = SD of drift rate (normal distr.) \in (0,\infty)]
                                    z = c(0.5),                             ### z = mean start point (bias) \in [0,1]
                                    sz = c(0.1),                            ### sz = range of possible start points (unif ditr.; in units of a-z) \in [0,1]
                                    t0 = seq(0, mint0-0.15, length.out=3),                   ### t0 = minimal motor time \in (0,\infty)]
                                    st0 = c(0.1,  0.5),                     ### st0 = range of possible motor times (unif. distr.) \in [0, t0/2]
                                    theta0 = seq(0.8, 1.5,length.out = 3),  ### theta0 = lowest threshold for confidence rating (in difference from threshold / a)
                                    thetamax = seq(2, 3.5,length.out = 3),    ### thetamax = highest threshold for confidence rating (in distance from threshold / a)
                                    tau = tau,                              ### tau = confidence rating time
                                    sig = seq(0.01, 0.5, length.out = 2),      ### sig = variability in visibility accumulation process
                                    w = seq(0.3, 0.7, length.out = 3),      ### w = weight bewtween evidence and visibility for confidence judgement
                                    sigmu = seq(0, 1, length.out = 3)),      ### sigmu = variability in drift rate of visibility accumulator
                        expand.grid(a = c(1.3,1.7, 2.5),
                                    vmin = c(0.01, 0.1),
                                    vmax = c(1.4, 2.5, 3.7, 5),
                                    sv = c(0.01, 0.8, 1.5),
                                    z = c(0.3,0.5, 0.7),
                                    sz = c(0.01, 0.4),
                                    t0 = seq(0, mint0-0.15, length.out=3),
                                    st0 = c(0.1, 0.3, 0.7),
                                    theta0 = seq(0.2, 1.5,length.out = 3),
                                    thetamax = seq(1.6, 2.5,length.out = 3),
                                    tau = tau))
  }
  init_grid <- subset(init_grid, t0+tau <= mint0)
  if (optim_method=="Nelder-Mead") {
    ## change parametrisation (should be on the whole real line) and
    #  span V-parameters between vmin and vmax equidistantly for all conditions
    inits <- data.frame(matrix(data=NA, nrow= nrow(init_grid),
                               ncol = switch(which(model==c( "WEVmu","2DSD")),3,0)+
                                 7+nConds+(nRatings-1)+as.numeric(!sym_thetas)*(nRatings-1)))
    inits[,1] <- log(init_grid$a)
    for (i in 0:(nConds-1)){
      if (nConds == 1) {
        inits[,2] <- log((init_grid$vmin+init_grid$vmax)/2)
      } else {
        inits[,2+i] <- log(init_grid$vmin+(i/(nConds-1))^2*(init_grid$vmax-init_grid$vmin)) ###  We assume a different V (mean drift rate) for the different conditions --> nConds parameters
      }
    }

    inits[,(2+nConds)] <-  log(init_grid$sv) # one SV (SD of drift rate) for all the different conditions
    inits[,nConds+3] <- qnorm(init_grid$z)
    inits[,nConds+4] <- qnorm(init_grid$sz)
    inits[,nConds+5] <- log(init_grid$t0)
    inits[,nConds+6] <- log(init_grid$st0)
    if (restr_tau == Inf) {
      inits[,nConds+7] <- log(init_grid$tau)
    } else {
      inits[,nConds+7] <- qnorm(init_grid$tau / restr_tau)
    }
    inits[,nConds+8] <- init_grid$theta0
    if (nRatings > 2) {
      inits[,(nConds+9):(nConds+6+(nRatings))] <- log((init_grid$thetamax-init_grid$theta0)/(nRatings-2))
    }
    if (!sym_thetas) {
      inits[,nConds+7+nRatings] <- init_grid$theta0
      if (nRatings > 2) {
        inits[,(nConds+8+nRatings):(nConds+5+2*nRatings)] <- log((init_grid$thetamax-init_grid$theta0)/(nRatings-2))
      }
    }
    if (model!="2DSD") {
      index_lag <- (nRatings-1)*as.numeric(!sym_thetas)
      inits[,(nConds+7+nRatings+index_lag)] <- log(init_grid$sig)
      inits[,(nConds+8+nRatings+index_lag)] <- qnorm(init_grid$w)
      inits[, (nConds+9+nRatings+index_lag)] <- log(init_grid$sigmu)
    }


    ##replace all +-Inf with big/tiny numbers
    inits[inits==Inf]<- 1e6
    inits[inits==-Inf]<- -1e6

    return(inits)


  } else {


    if (nConds==1) {
      init_grid$v1 <- (init_grid$vmin+init_grid$vmax)/2
    } else {
      for (i in 0:(nConds-1)){
        init_grid[paste("v", i+1, sep="")] <- init_grid$vmin+(i/(nConds-1))^2*(init_grid$vmax-init_grid$vmin)
      }
    }

    if (sym_thetas) {
      init_grid["theta1"] <- init_grid$theta0
      if (nRatings > 2) {
        for (i in 2:(nRatings-1)) {
          init_grid[paste("dtheta", i, sep="")] <- (init_grid$thetamax-init_grid$theta0)/(nRatings-2)
        }
        cols_theta <- c("theta1", paste("dtheta", 2:(nRatings-1), sep=""))
      } else {
        cols_theta <- c("theta1")
      }
    } else {
      init_grid[c("thetaUpper1", "thetaLower1")] <- init_grid$theta0
      if (nRatings > 2) {
        for (i in 2:(nRatings-1)) {
          init_grid[paste(c("dthetaUpper", "dthetaLower"), i, sep="")] <- (init_grid$thetamax-init_grid$theta0)/(nRatings-2)
        }
        cols_theta <- c('thetaLower1', paste("dthetaLower", 2:(nRatings-1), sep=""),
                        'thetaUpper1', paste("dthetaUpper", 2:(nRatings-1), sep=""))
      } else {
        cols_theta <- c("thetaLower1", "thetaUpper1")
      }
    }
  }

  if (model == "2DSD") {
    return(init_grid[c('a', 'z', 'sz',
                       paste("v", 1:nConds, sep=""),
                       'st0', 'sv', 't0',
                       cols_theta,
                       'tau')])
  } else {
    return(init_grid[c('a', 'z', 'sz',
                       paste("v", 1:nConds, sep=""),
                       'st0', 'sv', 't0',
                       cols_theta,
                       'tau', 'w', 'sig', 'sigmu')])
  }
}



neglikelihood_free <-   function(p, data, model,
                                restr_tau, nConds, nRatings, sym_thetas, simult_conf,
                                precision=3)
{
  # get parameter vector back from real transformations
  p <- c(t(p))

  paramDf <-  data.frame(matrix(nrow=1, ncol=0))
  paramDf$a <- exp(p[1])
  paramDf[,paste("v",1:(nConds), sep="")] <- exp(p[2:(1+nConds)])
  paramDf$sv <- exp(p[(2+nConds)])
  paramDf$z <- pnorm(p[3+nConds]) ## relative mean starting point
  paramDf$sz <- (min(paramDf$z, (1-paramDf$z))*2)*pnorm(p[4+nConds]) ##
  paramDf$t0 <- exp(p[5+nConds])
  paramDf$st0 <- exp(p[6+nConds])
  if (restr_tau == Inf) {
    paramDf$tau <- exp(p[7+nConds])
  } else {
    paramDf$tau <- restr_tau * pnorm(p[7+nConds])
  }
  if (nRatings > 2) {
    if (sym_thetas) {
      paramDf[,paste("theta",1:(nRatings-1), sep="")] <- cumsum(c(p[nConds+8], exp(p[(nConds+9):(nConds+6+nRatings)])))
    } else {
      paramDf[,paste("thetaUpper",1:(nRatings-1), sep="")] <- cumsum(c(p[nConds+8], exp(p[(nConds+9):(nConds+6+nRatings)])))
      paramDf[,paste("thetaLower",1:(nRatings-1), sep="")] <- cumsum(c(p[nConds+7+nRatings], exp(p[(nConds+8+nRatings):(nConds+5+2*nRatings)])))
    }
  } else {
    if (sym_thetas) {
      paramDf[,paste("theta",1:(nRatings-1), sep="")] <- p[nConds+8]
    } else {
      paramDf[,paste("thetaUpper",1:(nRatings-1), sep="")] <- p[nConds+8]
      paramDf[,paste("thetaLower",1:(nRatings-1), sep="")] <- p[nConds+7+nRatings]
    }
  }
  if (model=="2DSD") {
    negloglik <- -LogLikWEV(data, paramDf, model, simult_conf, precision, ceiling(precision*10/3), stop_on_error=FALSE)
    return(negloglik)
  }
  index_lag <- (nRatings-1)*as.numeric(!sym_thetas)
  paramDf$sig <- exp(p[7+nConds+nRatings+index_lag])
  paramDf$w <- pnorm(p[8+nConds+nRatings+index_lag])
  paramDf$sigmu <- exp(p[9+nConds+nRatings+index_lag])
  if (any(is.infinite(t(paramDf))) || any(is.na(t(paramDf)))) {
    return(1e12)
  }
  negloglik <- -LogLikWEV(data, paramDf, model, precision, ceiling(precision*10/3), stop_on_error=FALSE)
  return(negloglik)
}




neglikelihood_bounded <-   function(p, data, model,
                                restr_tau, nConds, nRatings, sym_thetas=FALSE, simult_conf,
                                precision=3)
{
  # get parameter vector back from real transformations
  paramDf <- p
  pnames <- names(paramDf)
  if (nRatings > 2) {
    if (sym_thetas) {
      paramDf[paste("theta", 2:(nRatings-1))] <- c(t(paramDf['theta1'])) + c(t(cumsum(paramDf[grep(pnames, pattern = "dtheta", value=TRUE)])))
    } else {
      paramDf[paste("thetaUpper", 2:(nRatings-1), sep="")] <- c(t(paramDf['thetaUpper1'])) + cumsum(c(t(paramDf[grep(pnames, pattern = "dthetaUpper", value=TRUE)])))
      paramDf[paste("thetaLower", 2:(nRatings-1), sep="")] <- c(t(paramDf['thetaLower1'])) + cumsum(c(t(paramDf[grep(pnames, pattern = "dthetaLower", value=TRUE)])))
    }
    paramDf <- paramDf[ -grep(names(paramDf), pattern="dtheta")]
  }
  paramDf['sz'] <- (min(paramDf['z'], 1-paramDf['z'])*2)*paramDf['sz']
  if (!is.data.frame(paramDf)) {
    paramDf2 <-   data.frame(matrix(nrow=1, ncol=length(paramDf)))
    paramDf2[1,] <- paramDf
    names(paramDf2) <- names(paramDf)
    paramDf <- paramDf2
  }
  negloglik <- -LogLikWEV(data, paramDf, model, simult_conf,
                          precision, ceiling(precision*10/3), stop_on_error=FALSE)
  return(negloglik)
}

fill_thresholds <- function(res, used_cats, actual_nRatings, model) {
  ### This function fills up the missing confidence thresholds with the best/easiest choices
  ### for the not identifiable or not reasonably fittable thresholds because some confidence
  ### categories are not used by the subject
  ### ToDo:   For sym_thetas==FALSE, use different nRatings for lower and upper responses in fitting
  symmetric_confidence_thresholds <- length(grep(pattern = "thetaUpper", names(res), value = T))<1
  if (symmetric_confidence_thresholds) {
    thetas <- rep(NA,(actual_nRatings-1))
    names(thetas) <- paste("theta", 1:(actual_nRatings-1), sep="")
    thetas[paste("theta", (used_cats[used_cats<max(used_cats)]), sep="")] <- c(t(res[,grep(pattern = "theta[0-9]", names(res), value = T)]))
    if (min(used_cats) >1) {
      thetas[paste("theta", 1:(min(used_cats)-1), sep="")] <- min(-1e+24, min(thetas, na.rm = TRUE))
    }
    if (max(used_cats)<actual_nRatings) {
      thetas[paste("theta", (max(used_cats):(actual_nRatings-1)), sep="")] <- max(1e+24, max(thetas, na.rm=TRUE))
    }
    thetas[which(is.na(thetas))] <- thetas[(which(is.na(thetas))-1)]
    res[,names(thetas)]<- thetas
  } else {
    thetasUpper <- rep(NA,(actual_nRatings-1))
    thetasLower <- rep(NA,(actual_nRatings-1))
    names(thetasUpper) <- paste("thetaUpper", 1:(actual_nRatings-1), sep="")
    names(thetasLower) <- paste("thetaLower", 1:(actual_nRatings-1), sep="")
    if (model == "2DSD") {
      thetasUpper[paste("thetaUpper", (used_cats[used_cats<max(used_cats)]), sep="")] <- c(t(res[,grep(pattern = "thetaUpper", names(res), value = T)]))
      thetasLower[paste("thetaLower", rev(actual_nRatings-(used_cats[used_cats<max(used_cats)])), sep="")] <- c(t(res[,grep(pattern = "thetaLower", names(res), value = T)]))
    } else {
      thetasUpper[paste("thetaUpper", (used_cats[used_cats<max(used_cats)]), sep="")] <- c(t(res[,grep(pattern = "thetaUpper", names(res), value = T)]))
      thetasLower[paste("thetaLower", (used_cats[used_cats<max(used_cats)]), sep="")] <- c(t(res[,grep(pattern = "thetaLower", names(res), value = T)]))
    }
    if (min(used_cats) >1) {
      if (model=="2DSD") {
        thetasUpper[paste("thetaUpper", 1:(min(used_cats)-1), sep="")] <- min(-1e+24, min(thetasUpper, na.rm=TRUE))
        thetasLower[paste("thetaLower", actual_nRatings - 1:(min(used_cats)-1), sep="")] <- max(1e+24, max(thetasLower, na.rm=TRUE))
      } else {
        thetasUpper[paste("thetaUpper", 1:(min(used_cats)-1), sep="")] <- min(-1e+24, min(thetasUpper, na.rm=TRUE))
        thetasLower[paste("thetaLower", 1:(min(used_cats)-1), sep="")] <- min(-1e+24, min(thetasLower, na.rm=TRUE))
      }
    }
    if (max(used_cats)<actual_nRatings) {
      if (model=="2DSD") {
        thetasUpper[paste("thetaUpper", (max(used_cats):(actual_nRatings-1)), sep="")] <- max(1e+24, max(thetasUpper, na.rm = TRUE))
        thetasLower[paste("thetaLower", actual_nRatings -(max(used_cats):(actual_nRatings-1)), sep="")] <- min(-1e+24, min(thetasUpper, na.rm=TRUE))
      } else {
        thetasUpper[paste("thetaUpper", (max(used_cats):(actual_nRatings-1)), sep="")] <- max(1e+24, max(thetasUpper, na.rm = TRUE))
        thetasLower[paste("thetaLower", (max(used_cats):(actual_nRatings-1)), sep="")] <- max(1e+24, max(thetasLower, na.rm = TRUE))
      }
    }
    while (any(is.na(thetasUpper))) {
      thetasUpper[which(is.na(thetasUpper))] <- thetasUpper[(which(is.na(thetasUpper))-1)]
    }
    while (any(is.na(thetasLower))) {
      if (model == "2DSD") {
        thetasLower[which(is.na(thetasLower))] <- thetasLower[(which(is.na(thetasLower))+1)]
      } else {
        thetasLower[which(is.na(thetasLower))] <- thetasLower[(which(is.na(thetasLower))-1)]
      }
    }

    res[,names(thetasUpper)]<- thetasUpper
    res[,names(thetasLower)]<- thetasLower
  }
  res
}
