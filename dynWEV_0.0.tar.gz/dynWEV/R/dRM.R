#' Independent and partially anti-correlated Race Model for Decision Confidence
#'
#' Probability densities for specific outcomes of a run in the independent Race Model (ddIRM)
#' or partially (anti-)correlated Race Model (ddPCRM), i.e. the probability of a given response
#' (win: winning accumulator) at a given time (rts) and the state of the loosing accumulator
#' (xj). The functions dIRM and dPCRM give the probability of a accumulator winning at a given time
#' and the loosing accumulator being in a given region (for discrete confidence responses).
#' The formulas for ddIRM and ddPCRM are taken from Moreno-Bote (2010).
#'
#' The parameters for the models are \code{mu1} and \code{mu2} for the drift rates, \code{a}, \code{b}
#' for the starting points of the two accumulators and \code{s}/\code{sigma} for the incremental standard deviation
#' of the processes and \code{t0} and \code{st0} for the  minimum and range of uniformly distributed
#' non-decision times (including encoding and motor time).
#' For dIRM and dPCRM additionally the parameters \code{th1} and \code{th2} for
#' the lower and upper bound of the interval for the loosing accumulator.
#'
#' @param rt a numeric vector of RTs. For convenience also a \code{data.frame} with
#' columns \code{rt} and \code{response} (and \code{xj}) is possible.
#' @param response numeric vector of 1s and 2s, giving the accumulator that hits his boundary first.
#' @param xj a numeric vector for the state of the loosing accumulator at decision time
#' (only for ddIRM and ddPCRM).
#' @param params a list or data.frame. Should include values for all parameters (mu1, mu2, a, b, s(or sigma), t0, st0,
#' and th1 and th2 (last four for dIRM and dPCRM, only)). See details for more information about the parametrization.
#' @param time_scaled logical. Whether the confidence measure should be time-scaled by the factor 1/sqrt(t).
#' This results in lower confidence when the reaction time is longer but the state of the second accumulator
#' is held constant.
#' @param step_width numeric. Step size for the integration in t0 (motor time). Default: 1e-6.
#'
#' @return Returns the numerical value of the probability density in a numerical vector of the same length as
#' rt or xj (whichever has length greater 1).
#'
#' @details For ddIRM and ddPCRM xj and rt have to have the same length or one must be of length 1.
#'
#' \strong{Parametrization}. In line with Moreno-Bote (2010), we keep
#'
#' For convenience, the function allows that the first argument is a \code{data.frame} containing the
#' information of the first, second (and third; for ddICM and ddPCRM) argument in the columns
#' (i.e., \code{rt} and \code{response} (and \code{xj})). Other columns (as well as passing
#' \code{response} and \code{xj} separately as argument) will be ignored.
#'
#' @note In contrast to the drift diffusion models (like \code{\link[rtdists:Diffusion]{ddiffusion}} and
#' \code{\link{dWEVmu}}), s is not a scaling factor, here and should also be specified.
#'
#' @references Moreno-Bote, R. (2010). Decision confidence and uncertainty in diffusion models with partially
#' correlated neuronal integrators. Neural Computation, 22(7), 1786–1811. https://doi.org/10.1162/neco.2010.12-08-930
#'
#'
#' @author R implementation and C code by Sebastian Hellmann.
#'
#' @useDynLib dynWEV, .registration = TRUE
#'
#' @name dRM
# @importFrom utils head
# @importFrom stats
# @importFrom pracma integral
#' @aliases dIRM dPCRM ddIRM ddPCRM
#' @importFrom Rcpp evalCpp


#' @rdname dRM
#' @export
dIRM <- function (rt,response=1,params, time_scaled = TRUE, step_width=NULL)
{
  # for convenience accept data.frame as first argument.
  if (is.data.frame(rt)) {
    response <- rt$response
    rt <- rt$rt
  }
  if (is.null(step_width)) {
    step_width = 0.089045 * exp(-1.037580*4)
  } else if (step_width>1) {
    step_width = 0.089045 * exp(-1.037580*step_width)
  }

  nn <- length(rt)
  if (!time_scaled) {
    params$wrt <- 0
    params$wint <- 0
    params$wx <- 1
  }

  if (!("wx" %in% names(params))) {
    params$wx <- 1
  }
  if (!("wrt" %in% names(params))) {
    params$wrt <- 0
  }
  if (!("wint" %in% names(params))) {
    params$wint <- 0
  }

  if (!("s" %in% names(params))) {
    params$s <- 1
  }
  pars <- prepare_RaceModel_parameter(response = response,
                                      params$mu1, params$mu2,
                                      params$a, params$b,
                                      params$s, params$th1, params$th2,
                                      params$t0, params$st0,
                                      params$wx, params$wrt, params$wint,
                                      nn)
  densities <- vector("numeric",length=nn)
  for (i in seq_len(length(pars$parameter_indices))) {
    ok_rows <- pars$parameter_indices[[i]]

    densities[ok_rows] <- d_IRM (rt[ok_rows]-pars$params[ok_rows[1],12],
                                 pars$params[ok_rows[1],1:11],
                                 pars$params[ok_rows[1],13],
                                 step_width)
  }
  abs(densities)
}

#' @rdname dRM
#' @export
dPCRM <- function (rt,response=1,params, time_scaled = TRUE, step_width=NULL)
{
  # for convenience accept data.frame as first argument.
  if (is.data.frame(rt)) {
    response <- rt$response
    rt <- rt$rt
  }
  if (is.null(step_width)) {
    step_width = 0.089045 * exp(-1.037580*4)
  } else if (step_width>1) {
    step_width = 0.089045 * exp(-1.037580*step_width)
  }

  nn <- length(rt)
  if (!time_scaled) {
    params$wrt <- 0
    params$wint <- 0
    params$wx <- 1
  }

  if (!("wx" %in% names(params))) {
    params$wx <- 1
  }
  if (!("wrt" %in% names(params))) {
    params$wrt <- 0
  }
  if (!("wint" %in% names(params))) {
    params$wint <- 0
  }

  if (!("s" %in% names(params))) {
    params$s <- 1
  }
  pars <- prepare_RaceModel_parameter(response = response,
                                      params$mu1, params$mu2,
                                      params$a, params$b,
                                      params$s, params$th1, params$th2,
                                      params$t0, params$st0,
                                      params$wx, params$wrt, params$wint,
                                      nn)
  densities <- vector("numeric",length=nn)
  for (i in seq_len(length(pars$parameter_indices))) {
    ok_rows <- pars$parameter_indices[[i]]

    densities[ok_rows] <- d_PCRM (rt[ok_rows]-pars$params[ok_rows[1],12],
                                  pars$params[ok_rows[1],1:11],
                                  pars$params[ok_rows[1],13],
                                  step_width)
  }
  abs(densities)
}



#' @rdname dRM
#' @export
ddIRM <- function (rt,response=1, xj=NULL, params)
{
  # for convenience accept data.frame as first argument.
  if (is.data.frame(rt)) {
    if ("response" %in% names(rt)) response <- rt$response
    if ("xj" %in% names(rt)) xj <- rt$xj
    rt <- rt$rt
  }

  nn <- max(length(rt), length(xj))
  if (length(rt)==1) {
    rt <- rep(rt, nn)
  }
  if (length(xj)==1) {
    xj <- rep(xj, nn)
  }
  if (!("s" %in% names(params))) {
    params$s <- 1
  }
  pars <- prepare_RaceModel_parameter(response = response,
                                      params$mu1, params$mu2,
                                      params$a, params$b,
                                      params$s, -1,0,-1,-1,-1,-1,-1,
                                      nn)
  densities <- vector("numeric",length=nn)
  for (i in seq_len(length(pars$parameter_indices))) {
    ok_rows <- pars$parameter_indices[[i]]

    densities[ok_rows] <- dd_IRM (rt[ok_rows],
                                  xj[ok_rows]+pars$params[ok_rows[1],(5-pars$params[ok_rows[1],13])],
                                  pars$params[ok_rows[1],1:5],
                                  pars$params[ok_rows[1],13])
  }
  abs(densities)
}



#' @rdname dRM
#' @export
ddPCRM <- function (rt,response=1, xj=NULL, params)
{
  # for convenience accept data.frame as first argument.
  if (is.data.frame(rt)) {
    if ("response" %in% names(rt)) response <- rt$response
    if ("xj" %in% names(rt)) xj <- rt$xj
    rt <- rt$rt
  }

  nn <- max(length(rt), length(xj))
  if (length(rt)==1) {
    rt <- rep(rt, nn)
  }
  if (length(xj)==1) {
    xj <- rep(xj, nn)
  }
  if (!("s" %in% names(params))) {
    params$s <- 1
  }
  pars <- prepare_RaceModel_parameter(response = response,
                                      params$mu1, params$mu2,
                                      params$a, params$b,
                                      params$s, -1,0,-1, -1,-1,-1,-1,
                                      nn)
  densities <- vector("numeric",length=nn)
  for (i in seq_len(length(pars$parameter_indices))) {
    ok_rows <- pars$parameter_indices[[i]]

    densities[ok_rows] <- dd_PCRM (rt[ok_rows],
                                   xj[ok_rows]+pars$params[ok_rows[1],(5-pars$params[ok_rows[1],13])],
                                  pars$params[ok_rows[1],1:5],
                                  pars$params[ok_rows[1],13])
  }
  abs(densities)
}

