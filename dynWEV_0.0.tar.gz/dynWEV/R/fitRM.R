#' Function for fitting parameters in Race Model (IRM and PCRM) confidence models
#'
#' Fits the parameters of the independent (IRM) and partially anti-correlated (PCRM) Race Model of Confidence.
#' So far, only a ML method is implemented, but a
#' quantile-Chi square method (as used by Ratcliff) will be implemented, too.
#' Also, see \code{\link{dRM}} for more information about the parameters.
#'
#' @param data a dataframe where each row is one trial. Containing following variables (column names can be changed by passing arguments of the form \code{rating=confidence} (unquoted!)):
#' * \code{condition} (for different levels of stimulus quality, will be transformed to a factor),
#' * \code{rating} (discrete confidence judgments, should be given as integer vector; otherwise will be transformed to integer),
#' * \code{rt} (giving the reaction times for the decision task),
#' * either 2 of the following (see details for more information about the accepted formats):
#'   * \code{stimulus} (encoding the stimulus category in a 2AFC task),
#'   * \code{response} (encoding the decision response),
#'   * \code{correct} (encoding whether the decision was correct; values in 0, 1)
#'   * \code{sbj} or \code{participant} (optional; giving the subject ID; only relevant if logging == TRUE;
#'                                                       if unique the ID is used in autosave files and logging messages;
#'                                                       if non-unique or missing AND logging ==TRUE, 999 will be used then)
#' @param model character scalar. One of "IRM" or "PCRM". ("IRMt" and "PCRMt" will also be accepted. In that case,
#' time_scaled is set to TRUE.)
#' @param method character scalar. The method (i.e. loss function) for the optimisation. So far, only "ML" is implemented.
#' @param time_scaled logical. Whether the confidence measure should be scaled by 1/sqrt(rt). Default: FALSE.
#' @param init_grid dataframe or NULL. Grid for the initial parameter search. Each row is one parameter constellation.
#' See details for more information. If \code{NULL} a default grid will be used.
#' @param grid_search logical. If FALSE, the grid search before the fitting is omitted. The fitting is then started with
#' a mean parameter set from the
#' default grid (if init_grid=NULL) or directly with the rows from init_grid, if not NULL. (Default: TRUE)
#' @param data_names named list (e.g. c("rating"="confidence")). Alternative possibility of giving other column names for the variables in the data. By default
#' column names are identical to the ones given in the data argument description.
#' @param fixed NULL or named vector/list. Name-value pairs for parameters that should be fixed and not fitted by the algorithm.
#' (e.g. c("st0"= 0, "sz"= 0) for forbidding inter trial variability of non-decision time and starting point)
#' @param nRatings integer. Number of rating categories. If NULL, the maximum of rating and length(unique(rating)) is used.
#' This argument is especially important for data sets where not the whole range of rating categories is realized.
#' If given, ratings has to be given as factor or integer.
#' @param sym_thetas logical. Whether the same thresholds should be used for both response directions.
#' @param logging logical. If TRUE, a folder autosave/fit**model** is created and messages about the process are printed
#' in a logging file and to console. Additionally intermediate results are saved in a .RData file with the
#' participant ID in the name.
#' @param opts list. A list for more control options in the optimisation routines (depending on the method). See details
#' for more information.
#' @param optim_method character. Determines which optimization function is used for the parameter estimation.
#' Either "bobyqa" (default), "L-BFGS-B" or "Nelder-Mead". "bobyqa" uses a box-constrained optimization with quadratic
#' interpolation. (See \code{\link[minqa]{bobyqa}} for more information.) The first two use a box-constraint optimization.
#' For Nelder-Mead a transfinite function rescaling is used (i.e. the constrained arguments are suitably transformed to
#' the whole real line)
#' @param useparallel logical. If TRUE the grid search in the beginning is done with a parallel back-end, using the \code{parallel} package.
#' @param n.cores integer. Number of cores used for parallelization. If NULL (default) the number of available cores -1 is used.
#' @param ... Possibility of giving alternative variable names (unquoted) in data frame (in the form \code{condition = SOA}).
#'
#' @return Gives a one-row data frame with columns for the different parameters as fitted result as well as
#' additional information about the fit (negLogLik (for final parameters), k (number of parameters), N (number of
#' data rows), BIC, AICc and AIC)
#'
#' @details The fitting involves a first grid search through the initial grid (given as argument or the default).
#' Then the best \code{nAttempts} parameter sets are chosen for an optimisation, which is done with R function
#' \code{\link[stats]{optim}} and a Nelder-Mead algorithm. This is restarted \code{nRestarts} times.
#'
#' \strong{method}. So far, only the ML method is implemented. This uses the Log-likelihood, \code{LogLikRM}, as a
#' cost function.
#'
#'  \strong{stimulus, response and correct}. Two of these columns must be given in data. If all three are given,
#'  correct will have no effect (and will be not checked!). stimulus and response can always be given in numerical
#'  format with values 1 and 2. Otherwise they will be transformed to integers by treating them as
#'  factors. Note, that giving one as numerical and the other as factor may be prone to errors, since the levels
#'  may not match the encoding of the other vector. Correct must always be given as a 0-1-vector.
#'  If stimulus is given together with response and they both do not match the above format, they need to have the
#'  same values/levels (if factor). In the case that only stimulus/response is given in any other format together
#'  with correct, the unique values will be sorted increasingly and the first value will be encoded as 1 and the
#'  second as 2.
#'
#' \strong{init_grid}. Each row should be one parameter set to check. The column names should include following:
#'  vmin, vmax (will be equidistantly spanned across conditions), a and b (decision thresholds), s, theta0
#'  (minimal threshold), thetamax (maximal threshold; the others will be equidistantly spanned symmetrically for
#'  both decisions).
#'
#'  \strong{opts}. A list with numerical values. Possible options are listed below (together with the optimization
#'  method they are used for).
#'  * \code{nAttempts} (all) number of best performing initial parameter sets used for optimization; default 5, if
#'  grid_search is TRUE.
#'  If grid_search is FALSE and init_grid is NULL, then nAttempts will be set to 1 (and any input will be ignored).
#'  If grid_search is FALSE and init_grid is not NULL, the rows of init_grid will be used from top to bottom
#'  (since no initial grid search is done) with not more than nAttempts rows used.
#'  * \code{nRestarts} (all) number of successive optim routines for each of the starting parameter sets; default 5,
#'  * \code{maxfun} (\code{'bobyqa'}) maximum number of function evaluations; default: 5000,
#'  * \code{maxit} (\code{'Nelder-Mead' and 'L-BFGS-B'}) maximum iterations; default: 2000,
#'  * \code{reltol} (\code{'Nelder-Mead'})relative tolerance; default:  1e-6),
#'  * \code{factr} (\code{'L-BFGS-B'})tolerance in terms of reduction factor of the objective, default: 1e-10)
#'
#' @md
#'
#' @references Moreno-Bote, R. (2010). Decision confidence and uncertainty in diffusion models with partially
#' correlated neuronal integrators. Neural Computation, 22(7), 1786–1811. https://doi.org/10.1162/neco.2010.12-08-930
#'
#' https://nashjc.wordpress.com/2016/11/10/why-optim-is-out-of-date/
#'
#' https://hwborchers.lima-city.de/Presents/ROptimSlides4.pdf
#'
#'
#'
#' @author Sebastian Hellmann.
#'
#' @useDynLib dynWEV, .registration = TRUE
#'
#' @name fitRM
#' @importFrom stats setNames aggregate optim
#' @importFrom minqa bobyqa
#' @importFrom dplyr if_else case_when rename
#' @import logger
#' @import parallel
#' @importFrom magrittr %>%
#' @importFrom rlang .data
# @importFrom pracma integral
#' @aliases fitIRM fitPCRM
#' @importFrom Rcpp evalCpp
#'

#' @rdname fitRM
#' @export
fitRM <- function(data, model = "IRM", method="ML",
                  init_grid = NULL, grid_search = TRUE,
                  fixed=NULL,  nRatings = NULL, sym_thetas=FALSE,
                  logging=FALSE, opts=list(), optim_method = "bobyqa", time_scaled= FALSE, data_names = NULL,
                  useparallel = FALSE, n.cores=NULL,...){ #  ?ToDO: vary_sv=FALSE, RRT=NULL, vary_tau=FALSE


  #### Check argument types ####
  if (!is.character(method)) stop(paste("method must be character, but is ", typeof(method), sep=""))
  if (length(method)!=1) stop(paste("method must be of length 1, it's ", length(method), sep=""))

  if (!is.logical(grid_search)) stop(paste("grid_search must be logical, but is ", typeof(grid_search), sep=""))
  if (length(grid_search)!=1) stop(paste("grid_search must be of length 1, it's ", length(grid_search), sep=""))

  data <- rename(data, ...)
  if (!is.list(fixed)) fixed <- as.list(fixed)

  #### Check for opts given ####
  opts_missing <- !(c("nAttempts", "nRestarts", "maxfun", "maxit", "reltol", "factr") %in% names(opts))
  opts <- c(opts,
            setNames(as.list(c(5, 5, 8000, 2*1e+3,1e-6, 1e-10)[opts_missing]),
                     c("nAttempts", "nRestarts","maxfun", "maxit", "reltol", "factr")[opts_missing]))
  optim_method <- match.arg(optim_method, c("bobyqa", "L-BFGS-B", "Nelder-Mead"))

  if (!is.null(init_grid)) {
    if (nrow(init_grid)< opts$nAttempts) {
      opts$nAttempts <- nrow(init_grid)
      if (!opts_missing[1]) {
        message("opts$nAttempts is reduced to nrow(init_grid).")
      }
    }
  }
  if (!grid_search && is.null(init_grid) && !opts_missing[1]) {
    opts$nAttempts <- 1
    message("opts$nAttempts is reduced to 1, since grid_search was omitted.")
  }

  #### Check for column names given ####
  names_missing <- !(c("condition","response","stimulus","rating", "rt", "sbj", "correct") %in% names(data_names))
  data_names <- c(data_names,
                  setNames(as.list(c("condition","response","stimulus","rating", "rt", "sbj", "correct")[names_missing]),
                           c("condition","response","stimulus","rating", "rt", "sbj", "correct")[names_missing]))

  #### Process data input ####
  ### extract columns and check right formatting:
  cols <- names(data)
  condition <- data[[data_names$condition]]
  if(!is.factor(condition)) {
    condition <- factor(condition, levels=sort(unique(condition)))
  }
  if (data_names$stimulus %in% cols) {
    stimulus <- data[[data_names$stimulus]]
  }
  if (data_names$response %in% cols) {
    response <- data[[data_names$response]]
  }
  if (!exists("stimulus")) {
    if (!(data_names$correct %in% cols)) {stop("Column names in data must contain 2 of following 3: stimulus, response, correct or must be specified with the data_names argument.")}
    correct <- data[[data_names$correct]]
    if (("upper" %in% response)||("lower" %in% response)) {
      response <- as.numeric(factor(response, levels = c("upper", "lower")))
    } else {
      stim_levels <- sort(unique(response))
      if (length(stim_levels) != 2) {stop(paste("Response must have exactly two unique values! Values are: ", paste(stim_levels, collapse = ", ")))}
      response <- as.integer(factor(response, levels=(stim_levels)))

    }
    stimulus <- if_else(as.logical(correct), response, 3-response)
  } else {
    if (!exists("response")) {
      if (!("correct" %in% cols)) {stop("Column names in data must contain 2 of following 3: stimulus, response, correct or must be specified with the data_names argument.")}
      correct <- data[[data_names$correct]]
      if (!(all(stimulus %in% c(1,2)))) {
        stim_levels <- sort(unique(stimulus))
        if (length(stim_levels) != 2) {stop(paste("Stimulus must have exactly two unique values! Values are: ", paste(stim_levels, collapse = ", ")))}
        stimulus <- if_else(stimulus==stim_levels[1],1,2)
      }
      response <- if_else(as.logical(correct), stimulus, 3-stimulus)
    } else {
      if (!all(stimulus %in% c(1,2)) || !all(response %in% c(1,2))) {
        stim_levels <- sort(unique(response))
        response <- as.integer(factor(response, levels=(stim_levels)))
        if (!(all(stimulus %in% c(1,2)))) {
          if (!(all(stimulus %in% stim_levels))) {
            stop("Values in stimulus must either be in c(1,2) or same values as in response")
          } else {
            stimulus <- if_else(stimulus == stim_levels[1], 1, 2)
          }
        }
      }
    }
  }
  rt <- data[[data_names$rt]]
  rating <- data[[data_names$rating]]
  if (!is.numeric(rating)){
    rating <- as.integer(as.factor(rating))
  }
  if (!is.integer(rating)){
    rating <- as.integer(rating)
  }
  if (is.integer(rating)) {
    if (is.null(nRatings)) {
      nRatings <- max(rating)
    }
    if (max(length(unique(rating)), max(rating)+1-min(rating))>nRatings && any(rating==0)) {
      rating <- rating + 1L
      nRatings <- nRatings + 1
    }
  }
  if (length(unique(rating))< nRatings) {
    # If some rating categories are not used, we fit less thresholds numerically and fill up the
    # rest by the obvious best-fitting thresholds (e.g. +/- Inf for the lowest/highest...) in the end.
    # Therefore, save the true rating-vector for later recovery of which thresholds are indeed fitted and
    # reduce the vector for the fitting process to a integer vector without gaps
    ### ToDo:   For sym_thetas==FALSE, use different nRatings for lower and upper responses in fitting
    used_cats <- sort(unique(rating))
    actual_nRatings <- nRatings
    rating <- as.integer(as.factor(rating))
    nRatings <- length(unique(rating))
  }
  nConds <- length(levels(condition))
  df = data.frame(rating, stimulus, response, condition,rt)
  df$n = 1
  df = aggregate(n~rating+stimulus+response+condition+rt, df, sum)


  #### Initialise logger, if logging is wished ####
  if (logging==TRUE) {
    ## get participant ID for logging
    if (data_names$sbj %in% cols){
      sbjcol <- data_names$sbj
    } else if ("participant" %in% cols) {
      sbjcol <- "participant"
    }
    if (!exists("sbjcol")) {
      participant <- 999
    } else {
      if (length(unique(c(t(data[,sbjcol]))))==1) {
        participant <- as.numeric(data[1,sbjcol])
      } else {
        participant <- 999
      }
    }
    ## set logger and logging file
    dir.create("autosave", showWarnings = FALSE)
    dir.create(paste("autosave/fit", model, sep=""), showWarnings = FALSE)
    filename = paste("autosave/fit", model,"/part_", participant,".RDATA", sep = "")
    logger <- layout_glue_generator(format = paste('{level} [{time}] on process {pid} {fn} for participant ',participant,' and model ', model,': {msg}', sep=""))
    log_layout(logger)
    log_appender(appender_file(file=paste("autosave/fit", model,"/logging_", model, ".txt", sep="")), index=2)
    log_threshold(DEBUG, index=2)
    log_threshold(DEBUG)
    log_layout(logger, index=2)
  }


  #### Check model argument
  if (model=="IRMt") {
    model = "IRM"
    time_scaled=TRUE
  }
  if (model=="PCRMt") {
    model = "PCRM"
    time_scaled=TRUE
  }
  if (!model %in% c("IRM", "PCRM")) stop("model must be 'IRM', 'PCRM', 'IRMt' or 'PCRMt'")

  #### Create initial grid and cost-function ####
  inits <- create_grid_RM(init_grid=init_grid,
                       nConds=nConds, nRatings=nRatings, time_scaled=time_scaled,
                       optim_method=optim_method, minrt = min(rt),  sym_thetas=FALSE)
  if (!grid_search && is.null(init_grid)) {
    inits <- colMeans(inits)
  }

  # remove init_grid
  rm(init_grid)


  #### Initial grid search ####
  if (grid_search) {
    if (logging==TRUE) {
      log_info(paste(length(inits[,1]), "...parameter sets to check"))
      log_info(paste("data got ", nrow(df), " rows"))
      t00 <- Sys.time()
      log_info("Searching initial values ...")
    }

    if (optim_method == "Nelder-Mead") {
      if (useparallel) {
        if (is.null(n.cores)) {
          n.cores <- detectCores()-1
        }
        cl <- makeCluster(type="SOCK", n.cores)
        clusterExport(cl, c("df", "model", "time_scaled",
                            "nConds","nRatings", "sym_thetas"), envir = environment())
        logL <-
          parApply(cl, inits, MARGIN=1,
                   function(p) try(neglikelihood_free_RM(p, df, model, time_scaled, nConds, nRatings, sym_thetas),
                                   silent = TRUE))
        #stopCluster(cl)
      } else {
        logL <-
          apply(inits, MARGIN = 1,
                function(p) try(neglikelihood_free_RM(p, df, model, time_scaled, nConds, nRatings, sym_thetas),
                                silent = TRUE))
      }
    } else {
      if (useparallel) {
        if (is.null(n.cores)) {
          n.cores <- detectCores()-1
        }
        cl <- makeCluster(type="SOCK", n.cores)
        clusterExport(cl, c("df", "model", "time_scaled",
                            "nConds","nRatings", "sym_thetas"), envir = environment())
        logL <-
          parApply(cl, inits, MARGIN=1,
                   function(p) try(neglikelihood_bounded_RM(p, df, model, time_scaled, nConds, nRatings, sym_thetas),
                                   silent = TRUE))
        #stopCluster(cl)
      } else {
        logL <-
          apply(inits, MARGIN = 1,
                function(p) try(neglikelihood_bounded_RM(p, df, model, time_scaled,nConds, nRatings, sym_thetas),
                                silent=TRUE))
      }
    }
    logL <- as.numeric(logL)
    inits <- inits[order(logL),]
    if (logging==TRUE) {
      log_success(paste("Initial grid search took...",as.character(round(as.double(difftime(Sys.time(),t00,units = "mins")), 2))," mins"))
    }
  }
  if (optim_method!="Nelder-Mead") {
                      # a,  b,  t0, st0, wrt, wint, (if needed (time_scaled=TRUE)), v1, v2,....,,   thetaLower1, dthetaLower2.., thetaUpper1... (or theta1,...)
    lower_optbound <- c(0,  0,  0,  0,   rep(0, 2*as.numeric(time_scaled)),         rep(0, nConds), rep(rep(0, nRatings-1), 2-as.numeric(sym_thetas)))
    upper_optbound <- c(Inf,Inf,Inf,Inf, rep(Inf, 2*as.numeric(time_scaled)),       rep(Inf,nConds),rep(Inf, (2-as.numeric(sym_thetas))*(nRatings-1)))
  }
  #### Optimization ####
  if (logging==TRUE) {
    log_info("Start fitting ... ")
  }
  if (!useparallel) {
  noFitYet <- TRUE
    for (i in 1:opts$nAttempts){
      start <- c(t(inits[i,]))
      for (l in 1:opts$nRestarts){
        if (optim_method == "Nelder-Mead") {
          try(m <- optim(par = start,
                         fn = neglikelihood_free_RM,
                         data=df, model = model, time_scaled=time_scaled, nConds=nConds, nRatings=nRatings,
                         sym_thetas=sym_thetas,
                         method="Nelder-Mead",
                         control = list(maxit = opts$maxit, reltol = opts$reltol)))
        } else if (optim_method =="bobyqa") {
          names(start) <- names(inits)
          try(m <- bobyqa(par = start,
                          fn = neglikelihood_bounded_RM,
                          lower = lower_optbound, upper = upper_optbound,
                          data=df, model = model, time_scaled=time_scaled, nConds=nConds, nRatings=nRatings,
                          sym_thetas=sym_thetas,
                          control = list(maxfun=opts$maxfun,
                                         rhobeg = min(0.2, 0.2*max(abs(start))),
                                         npt = length(start)+5)))
          ## rhobeg should be: about 0.1*(greatest expected change in parameters --> <= 1-2 (for a, thetas or v's) )
          ##                   smaller than min(abs(upper-lower)) = min(1, restr_tau)
          ##                   --> so we use min(0.9*restr_tau, 0.2, 0.2*max(abs(par))). Default would be: min(0.95, 0.2*max(abs(par)))<= 0.5 (since a=2.5 is >=max(abs(par)))
          ## rhoend: use default of 1e-6*rhobeg
          if (exists("m") && class(m) != "try-error"){
            m$value <- m$fval
          }
        } else if (optim_method=="L-BFGS-B") {  ### ToDo: use dfoptim or pracma::grad as gradient!
          names(start) <- names(inits)
          try(m <- optim(par = start,
                         fn = neglikelihood_bounded_RM,
                         lower = lower_optbound, upper = upper_optbound,
                         data=df, model = model, time_scaled=time_scaled, nConds=nConds, nRatings=nRatings,
                         sym_thetas=sym_thetas,
                         method="L-BFGS-B",
                         control = list(maxit = opts$maxit, factr = opts$factr)))
        } else {
          stop(paste("Not implemented or unknown method: ", optim_method, ". Use 'bobyqa', Nelder-Mead' or 'L-BFGS-B' instead.", sep=""))
        }
        if (!exists("m") || class(m) == "try-error"){
          if (logging==TRUE) {
            log_error(paste("No fit obtained at attempt No.", i))
            log_error(paste("Used parameter set", paste(start, sep = "", collapse = " "), sep=" ", collapse = ""))
          }
          break
        }
        if (exists("m") && is.list(m)){
          if (noFitYet) {
            fit <- m
            noFitYet <- FALSE
            if (logging==TRUE) {
              log_info(paste("First fit obtained at attempt No.", i))
              attempt <- i
              save(logL, inits,  df,fit, attempt, file = filename)
            }
            start <- fit$par
          } else if (m$value < fit$value) {
            fit <- m
            if (logging==TRUE) {
              log_info(paste("New fit at attempt No.", i, " restart no. ", l))
              attempt <- i
              save(logL, inits,  df,fit, attempt, file = filename)
            }
            start <- fit$par
            log_info(paste("Finished attempt No.", i, " restart no. ", l))
          } # end of if better value
        }   # end of if we got a optim-result at all
      }     # end of for restarts
    }       # end of for initial start values
  } else {  # if useparallel
    starts <- inits[(1:opts$nAttempts),]
    parnames <- names(starts)

    optim_node <- function(start) {  # define optim-routine to run on each node
      noFitYet <- TRUE
      start <- c(t(start))
      for (l in 1:opts$nRestarts){
        if (optim_method == "Nelder-Mead") {
          try(m <- optim(par = start,
                         fn = neglikelihood_free_RM,
                         data=df, model = model, time_scaled=time_scaled, nConds=nConds, nRatings=nRatings,
                         sym_thetas=sym_thetas,
                         method="Nelder-Mead",
                         control = list(maxit = opts$maxit, reltol = opts$reltol)))
        } else if (optim_method =="bobyqa") {
          names(start) <- parnames
          try(m <- bobyqa(par = start,
                          fn = neglikelihood_bounded_RM,
                          lower = lower_optbound, upper = upper_optbound,
                          data=df, model = model, time_scaled=time_scaled, nConds=nConds, nRatings=nRatings,
                          sym_thetas=sym_thetas,
                          control = list(maxfun=opts$maxfun,
                                         rhobeg = min(0.2, 0.2*max(abs(start))),
                                         npt = length(start)+5)))
          ## rhobeg should be: about 0.1*(greatest expected change in parameters --> <= 1-2 (for a, thetas or v's) )
          ##                   smaller than min(abs(upper-lower)) = min(1, restr_tau)
          ##                   --> so we use min(0.9*restr_tau, 0.2, 0.2*max(abs(par))). Default would be: min(0.95, 0.2*max(abs(par)))<= 0.5 (since a=2.5 is >=max(abs(par)))
          ## rhoend: use default of 1e-6*rhobeg
          if (exists("m") && class(m) != "try-error"){
            m$value <- m$fval
          }
        } else if (optim_method=="L-BFGS-B") {  ### ToDo: use dfoptim or pracma::grad as gradient!
          names(start) <- parnames
          try(m <- optim(par = start,
                         fn = neglikelihood_bounded_RM,
                         lower = lower_optbound, upper = upper_optbound,
                         data=df, model = model, time_scaled=time_scaled, nConds=nConds, nRatings=nRatings,
                         sym_thetas=sym_thetas,
                         method="L-BFGS-B",
                         control = list(maxit = opts$maxit, factr = opts$factr)))
        } else {
          stop(paste("Not implemented or unknown method: ", optim_method, ". Use 'bobyqa', Nelder-Mead' or 'L-BFGS-B' instead.", sep=""))
        }
        if (!exists("m") || class(m) == "try-error"){
          break
        }
        if (exists("m") && is.list(m)){
          if (noFitYet) {
            fit <- m
            noFitYet <- FALSE
            start <- fit$par
          } else if (m$value < fit$value) {
            fit <- m
            start <- fit$par
          }
        }
      }
      if (exists("fit") && is.list(fit)){
        return(c(fit$value,fit$par))
      } else {
        return(rep(NA, length(start)+1))
      }
    } # end of node-function

    clusterExport(cl, c("parnames", "opts", "optim_method","optim_node" ), envir = environment())
    if (optim_method!="Nelder-Mead") {
      clusterExport(cl, c("lower_optbound", "upper_optbound"), envir = environment())
    }
    optim_outs <- parApply(cl, starts,MARGIN=1, optim_node )
    stopCluster(cl)
    optim_outs <- t(optim_outs)
    best_res <- optim_outs[order(optim_outs[,1]),][1,]
    fit <- list(par = best_res[-1], value=best_res[1])
  } # end of if-else useparallel

  #### Wrap up results ####
  res <-  data.frame(matrix(nrow=1, ncol=0))
  if(exists("fit") && is.list(fit)){
    k <- length(fit$par)
    N <- length(rating)

    p <- c(t(fit$par))
    if (optim_method=="Nelder-Mead") {
      res[,paste("v",1:(nConds), sep="")] <- exp(p[1:(nConds)])
      res$a <- exp(p[(1+nConds)])
      res$b <- exp(p[2+nConds])
      res$t0 <- exp(p[3+nConds])
      res$st0 <- exp(p[4+nConds])
      if (nRatings > 2) {
        if (sym_thetas) {
          paramDf[,paste("theta",1:(nRatings-1), sep="")] <- cumsum(c(p[nConds+5], exp(p[(nConds+6):(nConds+3+nRatings)])))
        } else {
          paramDf[,paste("thetaUpper",1:(nRatings-1), sep="")] <- cumsum(c(p[nConds+5], exp(p[(nConds+6):(nConds+3+nRatings)])))
          paramDf[,paste("thetaLower",1:(nRatings-1), sep="")] <- cumsum(c(p[nConds+4+nRatings], exp(p[(nConds+5+nRatings):(nConds+2+2*nRatings)])))
        }
      } else {
        if (sym_thetas) {
          paramDf[,paste("theta",1:(nRatings-1), sep="")] <- p[nConds+5]
        } else {
          paramDf[,paste("thetaUpper",1:(nRatings-1), sep="")] <- p[nConds+5]
          paramDf[,paste("thetaLower",1:(nRatings-1), sep="")] <- p[nConds+4+nRatings]
        }
      }
      if (time_scaled) {
        res$wx <- 1/(exp(p[length(p)-1])+exp(p[length(p)])+1)
        res$wrt <- exp(p[length(p)-1])/(exp(p[length(p)-1])+exp(p[length(p)])+1)
        res$wint <- exp(p[length(p)])/(exp(p[length(p)-1])+exp(p[length(p)])+1)
      } else {
        res$wx <- 1
        res$wrt <- 0
        res$wint <- 0
      }
    } else {
      names(p) <- names(inits)
      if (nRatings>2) {
        if (sym_thetas) {
          p[paste("theta", 2:(nRatings-1))] <- c(t(p['theta1'])) + c(t(cumsum(p[grep(names(p), pattern = "dtheta", value=TRUE)])))
        } else {
          p[paste("thetaUpper", 2:(nRatings-1), sep="")] <- c(t(p['thetaUpper1'])) + cumsum(c(t(p[grep(names(p), pattern = "dthetaUpper", value=TRUE)])))
          p[paste("thetaLower", 2:(nRatings-1), sep="")] <- c(t(p['thetaLower1'])) + cumsum(c(t(p[grep(names(p), pattern = "dthetaLower", value=TRUE)])))
        }
        p <- p[ -grep(names(p), pattern="dtheta")]
      }
      res <-   data.frame(matrix(nrow=1, ncol=length(p)))
      res[1,] <- p
      names(res) <- names(p)      # a, b, wrt and wint (maybe), v1, v2,....,, thetaLower1,dthetaLower2-4,   thetaUpper1,dthetaUpper2-4,
      if (exists("used_cats")) {
        # If some rating categories are not used, we fit less thresholds numerically and fill up the
        # rest by the obvious best-fitting thresholds (e.g. +/- Inf for the lowest/highest...)
        res <- fill_thresholds_RM(res, used_cats, actual_nRatings)
        nRatings <- actual_nRatings
        k <- ncol(res)
      }
      if (!time_scaled) {
        res$wx <- 1
        res$wrt <- 0
        res$wint <- 0
      } else {
        res$wx <- 1/(res$wrt+res$wint+1)
        res$wrt <- res$wrt/(res$wrt+res$wint+1)
        res$wint <- res$wint/(res$wrt+res$wint+1)
      }
      if (sym_thetas) {
        res <- res[,c('a','b', 't0', 'st0', paste("v", 1:nConds, sep=""), paste("theta", 1:(nRatings-1), sep=""), 'wx', 'wrt', 'wint')]
      } else {
        res <- res[,c('a','b', 't0', 'st0', paste("v", 1:nConds, sep=""), paste("thetaLower", 1:(nRatings-1), sep=""), paste("thetaUpper", 1:(nRatings-1), sep=""), 'wx', 'wrt', 'wint')]
      }
    }


    res$negLogLik <- fit$value
    res$N <- N
    res$k <- k
    res$BIC <-  2 * fit$value + k * log(N)
    res$AICc <- 2 * fit$value + k * 2 + 2*k*(k-1)/(N-k-1)
    res$AIC <- 2 * fit$value + k * 2
    if (logging==TRUE) {
      log_success("Done fitting and autosaved results")
      save(logL, df, res, file=filename)
    }
  }

  return(res)
}
