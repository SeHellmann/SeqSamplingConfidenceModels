#' Response Time Distributions and Confidence Judgments.
#'
#' \tabular{ll}{
#' Package: \tab dynWEV\cr
#' Type: \tab Package\cr
#' Version: \tab 0.0.1\cr
#' Date: \tab 2021-10-01\cr
#' Depends: \tab R (>= 3.5.0)\cr
#' License: \tab GPL (>=3)\cr
#' URL: \tab https://gitlab.pavlovia.org/SeHellmann\cr
#' }
#'
#' Provides response time and confidence distributions (density/PDF) for following models: 2DSD, dynWEV, IRM and PCRM
#'
#' @aliases dynWEV-package dWEV-package 2DSD-package
#' @name dynWEV-package
#' @docType package
#' @title The dynWEV Package
#' @author Sebastian Hellmann based on Henrik Singmann, Scott Brown, Matthew Gretton, Andrew Heathcote
#' @keywords package
NULL
