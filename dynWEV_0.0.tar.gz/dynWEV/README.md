This package provides probability density/likelihood functions for
several dynamic decision confidence models and additional functions for
fitting, simulations and predictions.

## Installation

Installation from GitHub (development version):

    devtools::install_github("SeHellmann/dynWEV")

Publication on the CRAN repository is in progress.

## Usage

``` r
library(dynWEV)
d2DSD(rt=0.7, th1=2.4, th2=2.5, response="lower", 
      tau=1, a=2, v=0.7, t0=0, z =0.5, sv=0, st0=0.1)
```

    ## [1] 0.001282543

``` r
dWEVmu(rt=0.7, th1=2.4, th2=2.5, response="lower", 
      tau=1, a=2, v=0.7, t0=0, z =0.5, sv=0, st0=0.1)
```

    ## [1] 0.000175504

## Workflow for data analysis

is an R Markdown document. Markdown is a simple formatting syntax for
authoring HTML, PDF, and MS Word documents. For more details on using R
Markdown see <http://rmarkdown.rstudio.com>.

``` r
summary(cars)
```

    ##      speed           dist       
    ##  Min.   : 4.0   Min.   :  2.00  
    ##  1st Qu.:12.0   1st Qu.: 26.00  
    ##  Median :15.0   Median : 36.00  
    ##  Mean   :15.4   Mean   : 42.98  
    ##  3rd Qu.:19.0   3rd Qu.: 56.00  
    ##  Max.   :25.0   Max.   :120.00

![](README_files/figure-markdown_github/pressure-1.png)

## Contact

For comments, remarks, and questions please contact me:
<sebastian.hellmann@ku.de> or [submit an
issue](https://github.com/SeHellmann/dynWEV/issues).
